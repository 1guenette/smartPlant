export { EnvConfig } from '../../src/client/app/shared/config/env.config';

