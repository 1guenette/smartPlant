import { serveProd } from '../../utils';

/**
 * Executes the build process, serving the files of the production environment using an `express` server.
 */
export = serveProd;
