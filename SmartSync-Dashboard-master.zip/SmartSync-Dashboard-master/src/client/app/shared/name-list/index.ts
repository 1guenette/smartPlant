/**
 * This barrel file provides the export for the shared NameListService.
 */
export * from './name-list.service';
