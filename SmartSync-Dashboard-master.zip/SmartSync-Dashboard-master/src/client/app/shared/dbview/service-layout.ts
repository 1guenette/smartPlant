import {Service} from '../service/service';

export class ServiceLayout {
  service: Service;
  pos_x: number;
  pos_y: number;
}
