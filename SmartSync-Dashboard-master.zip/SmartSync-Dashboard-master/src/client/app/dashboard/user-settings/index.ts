/**
 * This barrel file provides the export for the lazy loaded BlankpageComponent.
 */
export * from './userSettings.component';
export * from './userSettings.routes';
