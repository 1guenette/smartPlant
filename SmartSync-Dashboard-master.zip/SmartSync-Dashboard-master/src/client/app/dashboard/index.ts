/**
*	This barrel file provides the export for the lazy loaded DashboardComponent.
*/
export * from './dashboard.component';
export * from './dashboard.routes';
