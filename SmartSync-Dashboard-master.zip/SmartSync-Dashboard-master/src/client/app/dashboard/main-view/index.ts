/**
 * This barrel file provides the export for the lazy loaded MainViewComponent.
 */
export * from './main-view.component';
export * from './main-view.routes';
