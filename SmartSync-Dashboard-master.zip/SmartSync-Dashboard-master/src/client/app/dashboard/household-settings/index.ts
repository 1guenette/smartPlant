/**
 * This barrel file provides the export for the lazy loaded HouseholdSettingsComponent.
 */
export * from './householdSettings.component';
export * from './householdSettings.routes';
