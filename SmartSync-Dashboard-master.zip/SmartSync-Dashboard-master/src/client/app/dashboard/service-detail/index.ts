/**
 * This barrel file provides the export for the lazy loaded AboutComponent.
 */
export * from './service-detail.component';
export * from './service-detail.routes';
