/**
 * This barrel file provides the export for the lazy loaded AboutComponent.
 */
export * from './manage-views.component';
export * from './manage-views.routes';
