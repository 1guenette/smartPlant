/**
 * This barrel file provides the export for the lazy loaded AboutComponent.
 */
export * from './manage-users.component';
export * from './manage-users.routes';
