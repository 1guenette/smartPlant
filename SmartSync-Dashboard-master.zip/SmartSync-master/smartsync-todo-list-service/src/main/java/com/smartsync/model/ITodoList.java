package com.smartsync.model;

/**
 * @author Jack Meyer (jackcmeyer@gmail.com)
 *
 * The to do list interface
 */
public interface ITodoList {

}
