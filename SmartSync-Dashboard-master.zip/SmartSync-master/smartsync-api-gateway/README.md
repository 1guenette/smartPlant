# SmartSync API Gateway

This service is responsible for filtering requests and sercurity as an edge service. 

## Possible Requests

| Name         | URL                   | Description                     | 
|--------------|-----------------------|---------------------------------|
| User Service | localhost:8000/users/ | Access to the user microservice |
